import { Component, inject, input } from '@angular/core';
import { LocalManagerService, TodoStateService } from '../../services';
import { DefaultTodoItem, TodoItemInterface } from '../../models';

@Component({
  selector: 'app-todo-item',
  imports: [],
  templateUrl: './todo-item.html',
  styleUrl: './todo-item.css'
})
export class TodoItem {
  
  todo = input<TodoItemInterface>(DefaultTodoItem);

  localManager = inject(LocalManagerService);
  todoState = inject(TodoStateService);

  deleteTodo(){
    this.todoState.remove(this.todo().id)
    this.localManager.eraseToDoItem(this.todo().id)
  }


}
