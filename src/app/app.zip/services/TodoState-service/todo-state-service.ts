import { Injectable, signal } from '@angular/core';
import { TodoItemInterface } from '../../models';

@Injectable({
  providedIn: 'root'
})
export class TodoStateService {
  
  todos = signal<TodoItemInterface[]>([]);

  addTodo(todo: TodoItemInterface){
    this.todos.update(t => [...t, todo]);
  }

  remove(id: string) {
    this.todos.update(t => t.filter(todo => todo.id !== id));
  }

  loadFromStorage(items : TodoItemInterface[]) {
    this.todos.set(items)
  }

}
