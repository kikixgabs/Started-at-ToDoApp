export interface Subtask {
    id: string,
    content: string,
    completed: boolean;
}