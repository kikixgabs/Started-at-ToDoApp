export interface ThemeModel {
    name: 'light' | 'dark' | 'system',
    icon: string
}
