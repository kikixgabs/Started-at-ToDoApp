import { Component } from '@angular/core';
import { TodoList } from '../todo-list/todo-list';

@Component({
  selector: 'app-main-layout',
  imports: [TodoList],
  templateUrl: './main-layout.html',
  styleUrl: './main-layout.css'
})
export class MainLayout {

}
